package eu.barcikowski;

import eu.barcikowski.GUI.MainFrame;

public class Main {

    public static void main(String[] args) {

        MainFrame mainFrame = new MainFrame();
        mainFrame.initializeComponents();


}
}
